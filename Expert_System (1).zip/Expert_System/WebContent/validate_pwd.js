function CheckPassword(inputtxt) 
{ 
var paswd=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
if(inputtxt.value.match(paswd)) 
{ 
//alert('Registration Successful...')
return true;
}
else
{ 
alert('Password format:7 to 15 characters which contain only characters, numeric digits, underscore and first character must be a letter')
return false;
}
}  
