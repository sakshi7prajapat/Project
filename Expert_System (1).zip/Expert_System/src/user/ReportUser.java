package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ReportUser
 */
@WebServlet("/ReportUser")
public class ReportUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   PrintWriter out=response.getWriter();
	        try{
	        	
	           HttpSession session=request.getSession();
	           
	           Class.forName("com.mysql.jdbc.Driver");
	           Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem","root","");
	           Statement st=conn.createStatement();
	           int x=st.executeUpdate("INSERT INTO `report` (`reportid`, `reportby`, `userid`, `commentid`,`why`, `time`) VALUES (NULL, '"+session.getAttribute("userid")+"','"+request.getParameter("id")+"','"+request.getParameter("cid")+"', '"+request.getParameter("why")+"', current_timestamp());");
	           if(x!=0){
	               response.sendRedirect("user/ReportComment.jsp?q=User Reported...");
	           }
	           else{
	               response.sendRedirect("user/ReportComment.jsp?q=Oops something went wrong...");
	           }
	          }
	        catch(Exception ex){
	            out.print(ex.getMessage().toString());
	        }
	    }


	}
