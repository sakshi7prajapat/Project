package user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class UserRegistration
 */
@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
       try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem","root","");
           java.sql.Statement st = conn.createStatement();
           int x=st.executeUpdate("insert into user(name,email,password,status) values('"+request.getParameter("fname")+"','"+request.getParameter("emailId")+"','"+request.getParameter("password")+"','0')");
           if(x!=0){
               response.sendRedirect("UserRegistration.jsp?q=Registration succesful...");           
           }
           else{
               response.sendRedirect("userSignUp.jsp?q=Registration not successful!!");
           }
           
       
       }
       catch(ClassNotFoundException | SQLException ex){
           out.print(ex.getMessage().toString());
       }
        
    }
}