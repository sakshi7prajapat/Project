package user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdatePwdName
 */
@WebServlet("/UpdatePwdName")
public class UpdatePwdName extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			HttpSession session = request.getSession();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			Statement st = conn.createStatement();
			ResultSet res = st.executeQuery("select * from user where userid=1");
			while (res.next()) {
				if (res.getString("password").equals(request.getParameter("oldpwd"))) {
					if (res.getString("password").equals(request.getParameter("newpwd"))) {
						response.sendRedirect("user/EditProfile.jsp?q=Old and New Passwords are same...");
					} else {
						if (request.getParameter("newpwd").equals(request.getParameter("confirmpwd"))) {
							int x = st.executeUpdate("UPDATE `user` SET `password` = '" + request.getParameter("newpwd")
									+ "' WHERE `user`.`userid` = '" + session.getAttribute("userid") + "'");
							if (x != 0) {
								response.sendRedirect("user/EditProfile.jsp?q=Password updated...");
							}
						} else {
							response.sendRedirect(
									"user/EditProfile.jsp?q=New password and confirm password are different...");
						}
					}

				} else {
					response.sendRedirect("user/EditProfile.jsp?q=Incorrect old password...");

				}
			}
		} catch (Exception e) {

		}
	}

}
