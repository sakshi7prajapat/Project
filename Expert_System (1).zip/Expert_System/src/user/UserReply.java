package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserReply
 */
@WebServlet("/UserReply")
public class UserReply extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {
			HttpSession session = request.getSession();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			Statement st = conn.createStatement();
			int x = st.executeUpdate(
					"INSERT INTO `solution` (`ansid`, `queid`, `answer`, `expertid`, `userid`, `datetime`) VALUES (NULL, '"
							+ request.getParameter("qid") + "','" + request.getParameter("ans") + "', NULL,'"
							+ session.getAttribute("userid") + "', current_timestamp())");
			if (x != 0) {
				response.sendRedirect(
						"user/AnswerForm.jsp?q=" + request.getParameter("qid") + "&que=" + request.getParameter("que"));
			} else {
				response.sendRedirect("user/AnswerForm.jsp?q=error...");
			}
			conn.close();
		} catch (Exception ex) {
			out.print(ex.getMessage().toString());
		}
	}
}