
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserRegistrationSer
 */
@WebServlet("/UserRegistrationSer")
public class UserRegistrationSer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			java.sql.Statement st = conn.createStatement();
			if (request.getParameter("password").equals(request.getParameter("confirmpassword"))) {
				int x = st.executeUpdate(
						"insert into user(name,email,password,status) values('" + request.getParameter("fname") + "','"
								+ request.getParameter("email") + "','" + request.getParameter("password") + "','0')");
				if(x!=0){
				response.sendRedirect("UserLogin.jsp?q=Registration successful...");
				}
			} else {
				response.sendRedirect("UserRegistration.jsp?q=Enter correct password.....");
			}

		} catch (ClassNotFoundException | SQLException ex) {
			out.print(ex.getMessage().toString());
		}

	}
}