package expert;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UpdateProfileE
 */
@MultipartConfig
@WebServlet("/UpdateProfileE")
public class UpdateProfileE extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Part file = request.getPart("image");

		String imageFileName = file.getSubmittedFileName();// get selected image
															// file name
		System.out.println(imageFileName);

		// upload path where the original image is going to be uploaded
		String uploadPath = "C:/Users/lenovo/workspace/Expert_System/WebContent/expert/images/expert/" + imageFileName;
		String uploadPath2 = "C:/Users/lenovo/workspace/Expert_System/WebContent/admin/images/expert/" + imageFileName;
		String uploadPath3 = "C:/Users/lenovo/workspace/Expert_System/WebContent/user/images/expert/" + imageFileName;

		System.out.print(uploadPath);

		// Uploading image into images folder
		try {

			FileOutputStream fos = new FileOutputStream(uploadPath);
			InputStream is = file.getInputStream();
			byte[] data = new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
			is.close();

			FileOutputStream fos2 = new FileOutputStream(uploadPath2);
			InputStream is2 = file.getInputStream();
			byte[] data2 = new byte[is2.available()];
			is2.read(data2);
			fos2.write(data2);
			fos2.close();
			is2.close();

			FileOutputStream fos3 = new FileOutputStream(uploadPath3);
			InputStream is3 = file.getInputStream();
			byte[] data3 = new byte[is3.available()];
			is3.read(data3);
			fos3.write(data3);
			fos3.close();
			is3.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		// Database connectivity
		try {
			HttpSession session = request.getSession();
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			Statement st = conn.createStatement();
			int x = st.executeUpdate("update expert  SET `img` = '" + imageFileName + "' WHERE expertid='"
					+ session.getAttribute("expertid") + "'");

			if (x != 0) {

				
				
				
				response.sendRedirect("expert/EditProfile.jsp?q=Profile Photo Updated Successfully...");
			} else {
				response.sendRedirect("expert/EditProfile.jsp?q=Retry...");
			}
		} catch (Exception e) {

		}
	}

	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>

}
