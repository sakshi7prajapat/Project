
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ExpertResume
 */
@MultipartConfig
@WebServlet("/ExpertResume")
public class ExpertResume extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Part file = request.getPart("resume");

		String imageFileName = file.getSubmittedFileName();// get selected image
															// file name
		System.out.println(imageFileName);

		// upload path where the original image is going to be uploaded
		String uploadPath = "C:/Users/lenovo/workspace/Expert_System/WebContent/admin/resume/" + imageFileName;
		System.out.print(uploadPath);

		// Uploading image into images folder
		try {

			FileOutputStream fos = new FileOutputStream(uploadPath);
			InputStream is = file.getInputStream();
			byte[] data = new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();
			is.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			java.sql.Statement st = conn.createStatement();
			if (request.getParameter("password").equals(request.getParameter("confirmpassword"))) {
				int x = st.executeUpdate(
						"INSERT INTO `resume` (`resumeid`, `resumeby`, `email`, `password`, `resume`, `approved`, `time`) VALUES (NULL, '"
								+ request.getParameter("fname") + "','" + request.getParameter("email") + "','"
								+ request.getParameter("password") + "', '" + imageFileName + "', 'No', current_timestamp());");
				if (x != 0) {
					response.sendRedirect("testingResumeForm.jsp?q=Registration successful...");
				}
			} else {
				response.sendRedirect("testingResumeForm.jsp?q=Retry.....");
			}

		} catch (ClassNotFoundException | SQLException ex) {
			out.print(ex.getMessage().toString());
		}

	}
}