import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginSer")
public class LoginSer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
			Statement st = conn.createStatement();
			
			if (request.getParameter("type").equals("user")) {
				
				ResultSet res = st.executeQuery("select * from user where userid='" + request.getParameter("userid")
						+ "' and password='" + request.getParameter("password") + "' and status='0'");
				if (res.next()) {
										
						HttpSession session = request.getSession();
						session.setAttribute("userid", res.getInt("userid"));
						session.setAttribute("name", res.getString("name"));
						response.sendRedirect("user/Dashboard.jsp?q=" + res.getString("name"));
					
				}
				else{
					
					response.sendRedirect("UserLogin.jsp?q=Incorrect Id or Password...");
				}
				res.close();
			}

			else if (request.getParameter("type").equals("expert")) {
				
				ResultSet res = st.executeQuery("select * from expert where expertid='" + request.getParameter("userid")
						+ "' and password='" + request.getParameter("password") + "' and status='0'");
				
				if (res.next()) {
					
					HttpSession session = request.getSession();
					session.setAttribute("expertid", res.getInt("expertid"));
					session.setAttribute("name", res.getString("name"));
					session.setAttribute("cat", res.getString("categoryid"));
					response.sendRedirect("expert/Dashboard.jsp?q=" + res.getString("name"));
				} else {
					
					response.sendRedirect("ExpertLogin.jsp?q=Incorrect Id or Password...");
				}				
				res.close();
				
			} else if (request.getParameter("type").equals("admin")) {
				
				ResultSet res = st.executeQuery("select * from admin where adminid='" + request.getParameter("userid")
						+ "' and password='" + request.getParameter("password") + "'");
				if (res.next()) {
					
					HttpSession session = request.getSession();
					session.setAttribute("adminid", res.getString("adminid"));
					session.setAttribute("name", res.getString("name"));
					response.sendRedirect("admin/Dashboard.jsp?q=Login successful...");
				} else {
					
					response.sendRedirect("AdminLogin.jsp?q=Incorrect Id or Password...");
				}
				res.close();
				
			} else if (request.getParameter("type").equals("testing")) {
				
				ResultSet res = st.executeQuery("select * from testing where userid='" + request.getParameter("userid")
						+ "' and password='" + request.getParameter("password") + "'");
				if (res.next()) {
					
					HttpSession session = request.getSession();
					session.setAttribute("userid", res.getInt("userid"));

					response.sendRedirect("user/testing.jsp?q=" + res.getString("name"));
				} else {
					
					response.sendRedirect("TestingLogin.jsp?q=Incorrect Id or Password...");
				}
				res.close();
				
			}
			conn.close();
			
		} catch (Exception ex) {
			
			out.print(ex.getMessage().toString());
		}
	}
}
